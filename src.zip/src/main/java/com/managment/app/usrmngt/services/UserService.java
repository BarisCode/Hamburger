package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Role;
import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.entities.views.UserNewViewModel;
import com.managment.app.usrmngt.entities.views.UserProfileViewModel;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface UserService extends BaseService<User, Long> {

    boolean authenticate(String userName, String password);

    void resetPassword(String email);

    /**
     * Find {@link User} by it's email
     * @param email
     * @return
     */
    Optional<User> findByEmail(String email);

    /**
     * Find all {@link User} instance with the given types
     * @param types
     * @return
     */
    List<User> findByTypeIn(List<String> types);

    /**
     * Update user's password
     * @param password
     * @param userId
     */
    void updatePassword(String password, Long userId);

    /**
     * Save a given instance of {@link User}
     * @param user
     * @return
     */
    User save(User user);

    /**
     * Save instance of {@link UserNewViewModel}
     * @param model
     * @return
     */
    User save(UserNewViewModel model);

    /**
     * Update existing USER
     * @param model
     * @return
     */
    User update(UserProfileViewModel model);

    List<User> findAllCreatedToday();

    /**
     * Fetch last 4 teacher
     * @return
     */
    List<User> findLast4Teacher();
}
