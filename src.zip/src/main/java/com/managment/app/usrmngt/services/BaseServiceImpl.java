package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.repositories.BaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.Assert;

import java.io.Serializable;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public abstract class BaseServiceImpl<E, K extends Serializable> implements BaseService<E, K> {

    protected static final String ERROR_OBJECT_MANDATORY = "{0} could not be null";

    @Autowired
    private BaseRepository<E, K> repository;

    @Override
    public long count(Example<E> example) {
        Assert.notNull(example, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Example instance"));
        return repository.count(example);
    }

    @Override
    public long count(Specification<E> specification) {
        Assert.notNull(specification, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Specification instance"));
        return repository.count(specification);
    }

    @Override
    public boolean exists(Example<E> example) {
        Assert.notNull(example, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Example instance"));
        return repository.exists(example);
    }

    @Override
    public boolean existsById(K id) {
        Assert.notNull(id, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Object ID"));
        return repository.existsById(id);
    }

    @Override
    public Optional<E> findById(K id) {
        Assert.notNull(id, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Object ID"));
        return repository.findById(id);
    }

    @Override
    public Optional<E> findOne(Example<E> example) {
        Assert.notNull(example, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Example instance"));
        return repository.findOne(example);
    }

    @Override
    public Optional<E> findOne(Specification<E> specification) {
        Assert.notNull(specification, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Specification instance"));
        return repository.findOne(specification);
    }

    @Override
    public Page<E> findAll(Example<E> example, Pageable pageable) {
        Assert.notNull(example, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Example instance"));
        Assert.notNull(pageable, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Pageable instance"));
        return repository.findAll(example, pageable);
    }

    @Override
    public Page<E> findAll(Specification<E> specification, Pageable pageable) {
        Assert.notNull(specification, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Specification instance"));
        Assert.notNull(pageable, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Pageable instance"));
        return repository.findAll(specification, pageable);
    }

    @Override
    public DataTablesOutput<E> findAll(DataTablesInput input) {
        Assert.notNull(input, MessageFormat.format(ERROR_OBJECT_MANDATORY, DataTablesInput.class.getSimpleName()));
        return repository.findAll(input);
    }

    @Override
    public List<E> findByCreatedAtAfter(Date date) {
        Assert.notNull(date, MessageFormat.format(ERROR_OBJECT_MANDATORY, Date.class.getSimpleName()));
        return repository.findByCreatedAtAfter(date);
    }

    @Override
    public List<E> findByCreatedAtBetween(Date start, Date end) {
        Assert.notNull(start, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Start Date"));
        Assert.notNull(end, MessageFormat.format(ERROR_OBJECT_MANDATORY, "End date"));

        return repository.findByCreatedAtBetween(start, end);
    }

    @Override
    public List<E> findByIdIn(List<Long> ids) {
        Assert.notEmpty(ids, MessageFormat.format(ERROR_OBJECT_MANDATORY, "List ID"));
        return repository.findByIdIn(ids);
    }

    public static Date atStartOfDay(Date date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay);
    }

    public static Date atEndOfDay(Date date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
        return localDateTimeToDate(endOfDay);
    }

    private static LocalDateTime dateToLocalDateTime(Date date) {
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    private static Date localDateTimeToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
}
