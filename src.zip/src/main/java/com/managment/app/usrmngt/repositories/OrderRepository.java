package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends BaseRepository<Order, Long> , JpaRepository<Order, Long> {

}
