package com.managment.app.usrmngt.entities.views;

public enum UserType {
    ADMIN("fa fa-terminal"), CASHIER("fa fa-pencil") ;

    private String icon;

    UserType(String icon) {
        this.icon = icon;
    }

    public String getIcon() {
        return icon;
    }
}
