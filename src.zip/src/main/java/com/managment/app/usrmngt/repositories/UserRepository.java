package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface UserRepository extends BaseRepository<User, Long> {

    /**
     * Find {@link User} by it's email
     * @param email
     * @return
     */
    User findByEmail(String email);

    @Modifying
    @Query("update User u set u.password = :password where u.id = :id")
    void updatePassword(@Param("password") String password, @Param("id") Long id);

    /**
     * Fetch all {@link User} instances of the given types
     * @param types
     * @return
     */
    List<User> findByTypeIn(List<String> types);

    /**
     * Fetch last 4 entries
     * @return
     */
    List<User> findFirst4ByTypeOrderByCreatedAtDesc(String type);

}
