package com.managment.app.usrmngt.entities;

import lombok.*;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="products")
@EqualsAndHashCode(callSuper = true)
public class Product extends AbstractActiveDeletableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name="name")
    private String name;

    @Column(name = "unit_price")
    private Double price;
}
