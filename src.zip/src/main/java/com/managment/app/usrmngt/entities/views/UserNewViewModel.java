package com.managment.app.usrmngt.entities.views;

import com.managment.app.usrmngt.misc.FieldMatch;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

@Data
@FieldMatch(first = "email", second = "confirmEmail", message = "The email fields must match")
public class UserNewViewModel {

    @Email(message = "*Please provide a valid Email")
    @NotEmpty(message = "*Please provide an email")
    private String email;

    @Email(message = "*Please provide a valid Email")
    @NotEmpty(message = "*Please provide an email")
    private String confirmEmail;

    @NotEmpty(message = "*Please provide your first name")
    private String firstName;

    @NotEmpty(message = "*Please provide your last name")
    private String lastName;

    @NotEmpty(message = "*Please provide your type")
    private UserType type;

    private AddressNewViewModel address;
}
