package com.managment.app.usrmngt.misc;

import com.google.common.collect.Sets;
import org.thymeleaf.context.IExpressionContext;
import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.dialect.IExpressionObjectDialect;
import org.thymeleaf.expression.IExpressionObjectFactory;

import java.util.Set;

public class MathDialect extends AbstractDialect implements IExpressionObjectDialect {

    private static final String MATHS_EXPRESSION_NAME = "maths";

    public MathDialect() {
        super("Math");
    }

    @Override
    public IExpressionObjectFactory getExpressionObjectFactory() {
        return new IExpressionObjectFactory() {
            @Override
            public Set<String> getAllExpressionObjectNames() {
                return Sets.newHashSet(MATHS_EXPRESSION_NAME);
            }

            @Override
            public Object buildObject(IExpressionContext iExpressionContext, String s) {
                if(s.equals(MATHS_EXPRESSION_NAME)){
                    return new MathsUtils();
                }
                return null;
            }

            @Override
            public boolean isCacheable(String s) {
                return false;
            }
        };
    }

}
