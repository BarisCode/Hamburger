package com.managment.app.usrmngt.repositories;

import org.springframework.data.jpa.datatables.repository.DataTablesRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@NoRepositoryBean
public interface BaseRepository<E, K extends Serializable> extends JpaSpecificationExecutor<E>,
        QueryByExampleExecutor<E>,
        PagingAndSortingRepository<E, K>,
        DataTablesRepository<E, K> {

    /**
     * Fetch all instances created after a given date
     * @param date
     * @return
     */
    List<E> findByCreatedAtAfter(Date date);

    /**
     * Fetch all instances created between start date and end date
     * @param start
     * @param end
     * @return
     */
    List<E> findByCreatedAtBetween(Date start, Date end);

    /**
     * Fetch all instances with the given list id
     * @param ids
     * @return
     */
    List<E> findByIdIn(List<Long> ids);
}