package com.managment.app.usrmngt.controllers.web;

import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.entities.views.ForgotPasswordViewModel;
import com.managment.app.usrmngt.entities.views.ResetPasswordViewModel;
import com.managment.app.usrmngt.security.utils.TokenUtils;
import com.managment.app.usrmngt.services.email.EmailService;
import com.managment.app.usrmngt.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Controller
public class AuthenticationController {
    static final String VIEW_SIGN_IN = "pages/sign-in";
    static final String VIEW_SIGN_UP = "pages/sign-up";
    static final String VIEW_FORGOT_PASSWORD = "pages/forgot-password";
    static final String VIEW_RESET_PASSWORD = "pages/reset-password";


    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService;

    @ModelAttribute("forgotPasswordForm")
    public ForgotPasswordViewModel forgotPasswordViewModel() {
        return new ForgotPasswordViewModel();
    }

    @ModelAttribute("passwordResetForm")
    public ResetPasswordViewModel resetPasswordViewModel() {
        return new ResetPasswordViewModel();
    }

    @GetMapping(value= {"/", "/sign-in"})
    public String signIn() {
        return VIEW_SIGN_IN;
    }

    @GetMapping("/sign-up")
    public String showRegistrationForm(Model model) {
        return VIEW_SIGN_UP;
    }

    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return VIEW_FORGOT_PASSWORD;
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@ModelAttribute("forgotPasswordForm") @Valid ForgotPasswordViewModel resetPasswordViewModel,
                                        BindingResult result, HttpServletRequest request) {
        if (result.hasErrors()) {
            return VIEW_FORGOT_PASSWORD;
        }

        User user = userService.findByEmail(resetPasswordViewModel.getEmail()).orElse(null);
        if (user == null) {
            result.rejectValue("email", null, "we could not find an user for that email address");
            return VIEW_FORGOT_PASSWORD;
        }

        userService.resetPassword(user.getEmail());
        return "redirect:/forgot-password?success";
    }


    @GetMapping("/reset-password")
    public String showResetPasswordPage(@RequestParam(required = false) String token,
                                        Model model) {
        String email = TokenUtils.extractEmail(token);
        User user = userService.findByEmail(email).orElse(null);
        if (user == null) {
            model.addAttribute("error", "could not find user with given token");
        } else {
            model.addAttribute("token", token);
        }
        return VIEW_RESET_PASSWORD;
    }

    @PostMapping("/reset-password")
    public String processResetPassword(@ModelAttribute("passwordResetForm") @Valid ResetPasswordViewModel resetPasswordViewModel,
                                       BindingResult result, HttpServletRequest request) {
        if (result.hasErrors()) {
            result.rejectValue("password", null, "error");
            return "redirect:/reset-password?token=" + resetPasswordViewModel.getToken();
        }
        String email = TokenUtils.extractEmail(resetPasswordViewModel.getToken());
        User user = userService.findByEmail(email).orElse(null);
        if (user != null) {
            String updatePassword = bCryptPasswordEncoder.encode(resetPasswordViewModel.getPassword());
            user.setPassword(updatePassword);
            userService.save(user);
            return "redirect:/sign-in?resetSuccess";
        }
        return "redirect:/reset-password?token=" + resetPasswordViewModel.getToken();
    }
}
