package com.managment.app.usrmngt.services;

import com.google.common.collect.Sets;
import com.managment.app.usrmngt.entities.*;
import com.managment.app.usrmngt.entities.views.UserNewViewModel;
import com.managment.app.usrmngt.entities.views.UserProfileViewModel;
import com.managment.app.usrmngt.misc.CommonUtils;
import com.managment.app.usrmngt.repositories.UserRepository;
import com.managment.app.usrmngt.security.utils.TokenUtils;
import com.managment.app.usrmngt.services.email.EmailService;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Example;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.servlet.http.HttpServletRequest;
import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
@Service
public class UserServiceImpl extends BaseServiceImpl<User, Long> implements UserService {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private EmailService emailService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * {@link MapperFacade} instance for converting {@link UserNewViewModel}
     * instance to {@link User}.
     */
    @Autowired
    @Qualifier(value = "mapperUserNewViewModelToUser")
    public MapperFacade mapperUserNewViewModelToUser;

    /**
     * {@link MapperFacade} instance for converting {@link UserProfileViewModel}
     * instance to {@link User}.
     */
    @Autowired
    @Qualifier(value = "mapperUserProfileViewModelToUser")
    private MapperFacade mapperUserProfileViewModelToUser;

    /**
     * {@link MapperFacade} instance for converting {@link com.managment.app.usrmngt.entities.views.AddressViewModel}
     * instance to {@link Address}.
     */
    @Autowired
    @Qualifier(value = "mapperAddressViewModelToAddress")
    private MapperFacade mapperAddressViewModelToAddress;

    @Override
    public Optional<User> findByEmail(String email) {
        Assert.notNull(email, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Email"));
        return Optional.ofNullable(userRepository.findByEmail(email));
    }

    @Override
    public List<User> findByTypeIn(List<String> types) {
        Assert.notEmpty(types, "Types is mandatory and can not empty");
        return userRepository.findByTypeIn(types);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void updatePassword(String password, Long userId) {
        Assert.notNull(password, MessageFormat.format(ERROR_OBJECT_MANDATORY, "Password"));
        Assert.notNull(userId, MessageFormat.format(ERROR_OBJECT_MANDATORY, "User ID"));
        userRepository.updatePassword(password, userId);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public User save(User user) {
        Assert.notNull(user, MessageFormat.format(ERROR_OBJECT_MANDATORY, User.class.getSimpleName()));
        return userRepository.save(user);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public User save(UserNewViewModel model) {
        Assert.notNull(model, MessageFormat.format(ERROR_OBJECT_MANDATORY, UserNewViewModel.class.getSimpleName()));

        User user = mapperUserNewViewModelToUser.map(model, User.class);

        User finalUser = user;
        roleService.findOne(Example.of(Role.builder().name(model.getType().name()).build())).ifPresent(r -> {
            finalUser.setRoles(Sets.newHashSet(r));
        });
        String updatePassword = bCryptPasswordEncoder.encode(RandomStringUtils.randomAlphanumeric(5, 10));
        finalUser.setPassword(updatePassword);

        Address address = new Address();
        address.setStreet(new StringBuilder(model.getAddress().getStreetNo())
                .append(", ").append(model.getAddress().getStreetName()).toString());
        address.setPostCode(model.getAddress().getPostCode());
        address.setCountry(model.getAddress().getCountry());
        address.setCity(model.getAddress().getCity());
        user.setAddress(address);

        User saved = save(finalUser);

        String token = TokenUtils.createToken(saved.getEmail(), saved.getPassword(), 24L);
        String appUrl = CommonUtils.getAppUrl(request) + "/registration/" + model.getType().name().toLowerCase() + "?token=" + token;
        emailService.sendSimpleMessage(saved.getEmail(), "New user", appUrl);
        log.info("registration: {}", appUrl);
        return saved;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public User update(UserProfileViewModel model) {
        Assert.notNull(model, MessageFormat.format(ERROR_OBJECT_MANDATORY, UserProfileViewModel.class.getSimpleName()));

        AtomicReference<User> saved = new AtomicReference<>(null);
        userRepository.findById(model.getId()).ifPresent(user -> {
            // user = mapperUserProfileViewModelToUser.map(model, User.class);
            user.setEmail(model.getEmail());
            user.setFirstName(model.getFirstName());
            user.setLastName(model.getLastName());

            Address address = user.getAddress();
            address.setCity(model.getAddress().getCity());
            address.setCountry(model.getAddress().getCountry());
            address.setPostCode(model.getAddress().getPostCode());
            address.setStreet(model.getAddress().getStreet());

            saved.set(userRepository.save(user));
        });
        return saved.get();
    }

    @Override
    public List<User> findAllCreatedToday() {
        Date limit = atStartOfDay(new Date());
        return findByCreatedAtAfter(limit);
    }

    @Override
    public List<User> findLast4Teacher() {
        return userRepository.findFirst4ByTypeOrderByCreatedAtDesc("Teacher");
    }

    @Override
    public boolean authenticate(String email, String password) {
        AtomicBoolean result = new AtomicBoolean(false);

        findByEmail(email).ifPresent(user -> {
            result.set(bCryptPasswordEncoder.matches(password, user.getPassword()));
        });
        return result.get();
    }


    @Override
    public void resetPassword(String email) {
        findByEmail(email).ifPresent(user -> {
            String newPassword = RandomStringUtils.randomAlphanumeric(5, 10);
            user.setPassword(new BCryptPasswordEncoder().encode(newPassword));
            String token = TokenUtils.createToken(email, "", 15L);
            emailService.sendSimpleMessage(user.getEmail(), "reset Password Link",
                    CommonUtils.getAppUrl(request) + "/reset-password?token=" + token);

        });
    }
}
