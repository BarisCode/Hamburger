package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.OrderItem;
import org.springframework.stereotype.Service;

@Service
public class OrderItemImpl extends BaseServiceImpl<OrderItem, Long> implements OrderItemService {

}
