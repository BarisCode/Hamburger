package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.OrderItem;

public interface OrderItemRepository extends BaseRepository<OrderItem, Long> {

}
