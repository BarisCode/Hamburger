package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Product;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl extends BaseServiceImpl<Product, Long> implements ProductService{

}
