package com.managment.app.usrmngt.entities.views;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrdersViewModel {
    private Map<Long, Integer> orderViewModel = new HashMap<>();

}
