package com.managment.app.usrmngt.controllers.web;

import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class DashboardController {

    static final String VIEW_DASHBOARD = "pages/admin/dashboard";

    @Autowired
    private UserService userService;

    @GetMapping("/dashboard")
    public String show(Model model) {
        List<User> userServiceAllCreatedToday = userService.findAllCreatedToday();
        List<User> allCashiers = userService.findByTypeIn(Arrays.asList("Cashiers"));

        User allFilter = new User();
        allFilter.setActive(true);
        long allUsers = userService.count(Example.of(allFilter));

        model.addAttribute("users_new", userServiceAllCreatedToday.size());
        model.addAttribute("users_all", allUsers);

        return VIEW_DASHBOARD;
    }

}
