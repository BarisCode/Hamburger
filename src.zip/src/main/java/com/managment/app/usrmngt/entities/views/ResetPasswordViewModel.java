package com.managment.app.usrmngt.entities.views;

import com.managment.app.usrmngt.misc.FieldMatch;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@FieldMatch(first = "password", second = "confirmPassword", message = "The password fields must match")
public class ResetPasswordViewModel {

    @NotEmpty
    private String password;

    @NotEmpty
    private String confirmPassword;

    @NotEmpty
    private String token;
}
