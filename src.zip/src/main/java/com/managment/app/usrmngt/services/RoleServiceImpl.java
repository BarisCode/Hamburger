package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Role;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl extends BaseServiceImpl<Role, Long> implements RoleService {
}
