package com.managment.app.usrmngt.services.email;

import org.springframework.mail.SimpleMailMessage;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Map;

public interface EmailService {

    /**
     * send a simple text email
     * @param to
     * @param subject
     * @param body
     */
    void sendSimpleMessage(String to, String subject, String body);

    /**
     * send email with arguments
     * @param to
     * @param subject
     * @param template
     * @param arguments
     */
    void sendSimpleMessageWithTemplate(String to, String subject, SimpleMailMessage template, String... arguments);

    void sendMessageWithAttachment(String to,
                                   String subject,
                                   String text,
                                   String pathToAttachment);

    void sendMessageUsingThymeleafTemplate(String to,
                                           String subject,
                                           Map<String, Object> templateModel)
            throws IOException, MessagingException;
}
