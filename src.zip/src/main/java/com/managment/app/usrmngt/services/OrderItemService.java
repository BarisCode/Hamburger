package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.OrderItem;

public interface OrderItemService extends BaseService<OrderItem, Long> {
}
