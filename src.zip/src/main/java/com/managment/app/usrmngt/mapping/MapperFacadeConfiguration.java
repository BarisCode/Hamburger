package com.managment.app.usrmngt.mapping;

import com.managment.app.usrmngt.entities.Address;
import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.entities.views.*;
import com.managment.app.usrmngt.services.UserService;
import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * {@link MapperFacadeConfiguration} contains configuration for mapper facades
 * which allow to painlessly convert a given object of one type to another.
 *
 * @version 1.0
 * @since 1.0
 */
@Configuration
public class MapperFacadeConfiguration {

    private static final String CONST_PASS = "password";

    @Autowired
    private UserService userService;

    /**
     * Get a {@link MapperFacade} for conversion between {@link User} and
     * {@link UserNewViewModel} instances
     *
     * @return {@link MapperFacade} for conversion from {@link UserNewViewModel} to
     * {@link User} instances
     */
    @Bean(name = "mapperUserNewViewModelToUser")
    public MapperFacade mapperUserNewViewModelToUser() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(UserNewViewModel.class, User.class)
                .byDefault().register();

        return mapperFactory.getMapperFacade();
    }

    /**
     * Get a {@link MapperFacade} for conversion between {@link User} and
     * {@link UserNewViewModel} instances
     *
     * @return {@link MapperFacade} for conversion from {@link UserProfileViewModel} to
     * {@link User} instances
     */
    @Bean(name = "mapperUserProfileViewModelToUser")
    public MapperFacade mapperUserProfileViewModelToUser() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(UserProfileViewModel.class, User.class)
                .byDefault().register();


        return mapperFactory.getMapperFacade();
    }

    /**
     * Get a {@link MapperFacade} for conversion between {@link UserProfileViewModel} and
     * {@link User} instances
     *
     * @return {@link MapperFacade} for conversion from {@link User} to
     * {@link UserProfileViewModel} instances
     */
    @Bean(name = "mapperUserToUserProfileViewModel")
    public MapperFacade mapperUserToUserProfileViewModel() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(User.class, UserProfileViewModel.class)
                .byDefault().customize(new CustomMapper<User, UserProfileViewModel>() {
            @Override
            public void mapAtoB(User user, UserProfileViewModel userProfileViewModel, MappingContext context) {
                AddressViewModel addressViewModel = mapperAddressToAddressViewModel().map(user.getAddress(), AddressViewModel.class);
                userProfileViewModel.setAddress(addressViewModel);
            }
        }).register();

        return mapperFactory.getMapperFacade();
    }

    /**
     * Get a {@link MapperFacade} for conversion between {@link Address} and
     * {@link AddressViewModel} instances
     *
     * @return {@link MapperFacade} for conversion from {@link Address} to
     * {@link AddressViewModel} instances
     */
    @Bean(name = "mapperAddressToAddressViewModel")
    public MapperFacade mapperAddressToAddressViewModel() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(Address.class, AddressViewModel.class)
                .byDefault().register();
        return mapperFactory.getMapperFacade();
    }

    /**
     * Get a {@link MapperFacade} for conversion between {@link AddressViewModel} and
     * {@link Address} instances
     *
     * @return {@link MapperFacade} for conversion from {@link AddressViewModel} to
     * {@link Address} instances
     */
    @Bean(name = "mapperAddressViewModelToAddress")
    public MapperFacade mapperAddressViewModelToAddress() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(AddressViewModel.class, Address.class)
                .byDefault().register();
        return mapperFactory.getMapperFacade();
    }

    /**
     * Get a {@link MapperFacade} for conversion between {@link User} and
     * {@link RegisterViewModel} instances
     *
     * @return {@link MapperFacade} for conversion from {@link User} to
     * {@link RegisterViewModel} instances
     */
    @Bean(name = "mapperUserToRegisterViewModel")
    public MapperFacade mapperUserToRegisterViewModel() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(User.class, RegisterViewModel.class)
                .customize(new CustomMapper<User, RegisterViewModel>() {
                    @Override
                    public void mapAtoB(User user, RegisterViewModel registerViewModel, MappingContext context) {
                        registerViewModel.setId(user.getId());
                        registerViewModel.setFirstName(user.getFirstName());
                        registerViewModel.setLastName(user.getLastName());
                    }
                })
                .byDefault().register();
        return mapperFactory.getMapperFacade();
    }
}
