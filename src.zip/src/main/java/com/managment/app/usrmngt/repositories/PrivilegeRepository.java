package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.Privilege;

public interface PrivilegeRepository extends BaseRepository<Privilege, Long> {

    /**
     * Find {@link Privilege} instance by it's name
     * @param name
     * @return
     */
    Privilege findByName(String name);
}
