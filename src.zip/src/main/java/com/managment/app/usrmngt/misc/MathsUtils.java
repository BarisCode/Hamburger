package com.managment.app.usrmngt.misc;

import java.math.BigInteger;

public class MathsUtils {

    public Double multiply(BigInteger count, Double price){
        return count.doubleValue()*price;
    }
}
