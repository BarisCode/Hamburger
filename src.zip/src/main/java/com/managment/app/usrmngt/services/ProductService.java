package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Product;

public interface ProductService extends BaseService<Product, Long> {

}
