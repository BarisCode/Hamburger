package com.managment.app.usrmngt.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "address")
public class Address extends AbstractActiveDeletableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;

    @Column(name = "street")
    @NotEmpty(message = "*Please provide a street")
    private String street;

    @Column(name = "city")
    @NotEmpty(message = "*Please provide a city")
    private String city;

    @Column(name = "country")
    @NotEmpty(message = "*Please provide a country")
    private String country;

    @Column(name = "post_code")
    @NotEmpty(message = "*Please provide a post-code")
    private String postCode;

//    @OneToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "user_id", nullable = false)
//    private User user;
}
