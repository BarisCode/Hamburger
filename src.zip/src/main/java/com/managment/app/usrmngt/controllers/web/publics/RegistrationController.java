package com.managment.app.usrmngt.controllers.web.publics;

import com.managment.app.usrmngt.entities.*;
import com.managment.app.usrmngt.entities.views.RegisterViewModel;
import com.managment.app.usrmngt.security.utils.TokenUtils;
import com.managment.app.usrmngt.services.UserService;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.Duration;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/registration")
public class RegistrationController {
    static final String VIEW_CASHIER = "pages/public/registration/cashier";

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    private UserService userService;


    /**
     * {@link MapperFacade} instance for converting {@link User}
     * instance to {@link RegisterViewModel}.
     */
    @Autowired
    @Qualifier(value = "mapperUserToRegisterViewModel")
    public MapperFacade mapperUserToRegisterViewModel;

    @GetMapping("/cashier")
    public String showStudentRegistrationPage(@RequestParam(required = false) String token,
                                              Model model) {
        String email = TokenUtils.extractEmail(token);
        User user = userService.findByEmail(email).orElse(null);
        if (user == null) {
            model.addAttribute("error", "could not find user with given token");
        } else {
            model.addAttribute("token", token);
        }
        model.addAttribute("user", mapperUserToRegisterViewModel.map(user, RegisterViewModel.class));
        return VIEW_CASHIER;
    }

    @PostMapping("/process_user")
    public String processStudentRegistration(RegisterViewModel model) {
        userService.findById(model.getId()).ifPresent(user -> {
            user.setFirstName(model.getFirstName());
            user.setLastName(model.getLastName());
            user.setPassword(bCryptPasswordEncoder.encode(model.getPassword()));
            userService.save(user);
        });

        return "redirect:/sign-in";
    }

}
