package com.managment.app.usrmngt.entities.views;

import lombok.Data;

@Data
public class AddressNewViewModel {

    private String streetName;

    private String streetNo;

    private String city;

    private String country;

    private String postCode;
}
