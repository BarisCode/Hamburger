package com.managment.app.usrmngt.entities.views;

import lombok.Data;

@Data
public class RegistrationCourseViewModel {

    private String name;

    private Long duration;
}
