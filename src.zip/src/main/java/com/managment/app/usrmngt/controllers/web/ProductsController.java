package com.managment.app.usrmngt.controllers.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/products")
public class ProductsController {
    static final String VIEW_PRODUCTS = "pages/auth/products";
}
