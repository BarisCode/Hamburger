package com.managment.app.usrmngt.controllers.web;

import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.entities.views.UserNewViewModel;
import com.managment.app.usrmngt.services.RoleService;
import com.managment.app.usrmngt.services.UserService;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicBoolean;

@Controller
@RequestMapping("/admin/users")
public class UsersController {
    static final String VIEW_USERS_LIST = "pages/admin/users/list";

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    /**
     * {@link MapperFacade} instance for converting {@link UserNewViewModel}
     * instance to {@link User}.
     */
    @Autowired
    @Qualifier(value = "mapperUserNewViewModelToUser")
    private MapperFacade mapperUserNewViewModelToUser;

    @GetMapping("/list")
    public String showUsers(Model model) {
        model.addAttribute("user_new", new UserNewViewModel());
        return VIEW_USERS_LIST;
    }

    @PostMapping("/post_new_user")
    public String processCreateUser(@RequestParam(required = false, name = "file") MultipartFile file,
                                    UserNewViewModel model,
                                    RedirectAttributes redirectAttributes) {
        AtomicBoolean emailExists = new AtomicBoolean(false);
        userService.findByEmail(model.getEmail()).ifPresent(user -> {
            emailExists.set(true);
            redirectAttributes.addFlashAttribute("email", "This email already exists!");
        });

        if (emailExists.get()) {
            redirectAttributes.addFlashAttribute("user_new", model);
            return "redirect:/admin/users/list";
        }

        User user = userService.save(model);

        redirectAttributes.addFlashAttribute("success", "New user [" + user.getLastName() + "] saved successfully");
        return "redirect:/admin/users/list";
    }

    /**
     * Convert {@link MultipartFile} instance to {@link File}
     * @param file
     * @param filename
     * @return
     */
    private File convert(MultipartFile file, String filename) {
        File convFile = new File(filename);
        FileOutputStream fileOutputStream = null;

        try {
            boolean created = convFile.createNewFile();
            if (created) {
                fileOutputStream = new FileOutputStream(convFile);
                fileOutputStream.write(file.getBytes());
                fileOutputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fileOutputStream);
        }

        return convFile;
    }

    private void close(FileOutputStream fileOutputStream) {
        if (fileOutputStream != null) {
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

