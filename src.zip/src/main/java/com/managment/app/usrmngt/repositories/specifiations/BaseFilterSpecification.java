package com.managment.app.usrmngt.repositories.specifiations;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.time.chrono.ChronoLocalDate;
import java.util.function.Function;

@Component
public abstract class BaseFilterSpecification<E> {

    /**
     * {@link FilterSpecifications} for Entity {@link E} and Field type
     * {@link ChronoLocalDate} (LocalDate)
     */
    @Autowired
    private FilterSpecifications<E, ChronoLocalDate> dateTypeSpecifications;

    /**
     * {@link FilterSpecifications} for Entity {@link E} and Field type
     * {@link String}
     */
    @Autowired
    private FilterSpecifications<E, String> stringTypeSpecifications;

    /**
     * {@link FilterSpecifications} for Entity {@link E} and Field type
     * {@link Integer}
     *
     */
    @Autowired
    private FilterSpecifications<E, Integer> integerTypeSpecifications;

    /**
     * {@link FilterSpecifications} for Entity {@link E} and Field type {@link Long}
     */
    @Autowired
    private FilterSpecifications<E, Long> longTypeSpecifications;

    /**
     * Converter Functions
     */
    @Autowired
    protected Converters converters;

    /**
     * Returns the Specification for Entity {@link E} for the given fieldName and
     * filterValue for the field type Date
     *
     * @param fieldName
     * @param filterValue
     * @return
     */
    public Specification<E> getDateTypeSpecification(String fieldName, String filterValue) {
        return getSpecification(fieldName, filterValue, converters.getFunction(ChronoLocalDate.class),
                dateTypeSpecifications);
    }

    /**
     * Returns the Specification for Entity {@link E} for the given fieldName and
     * filterValue for the field type String
     *
     * @param fieldName
     * @param filterValue
     * @return
     */
    public Specification<E> getStringTypeSpecification(String fieldName, String filterValue) {
        return getSpecification(fieldName, filterValue, converters.getFunction(String.class), stringTypeSpecifications);
    }

    /**
     * Returns the Specification for Entity {@link E} for the given fieldName and
     * filterValue for the field type Long
     *
     * @param fieldName
     * @param filterValue
     * @return
     */
    public Specification<E> getLongTypeSpecification(String fieldName, String filterValue) {
        return getSpecification(fieldName, filterValue, converters.getFunction(Long.class), longTypeSpecifications);
    }


    /**
     * Returns the Specification for Entity {@link E} for the given fieldName and
     * filterValue for the field type Integer
     *
     * @param fieldName
     * @param filterValue
     * @return
     */
    public Specification<E> getIntegerTypeSpecification(String fieldName, String filterValue) {
        return getSpecification(fieldName, filterValue, converters.getFunction(Integer.class),
                integerTypeSpecifications);
    }

    /**
     * Generic method to return {@link Specification} for Entity {@link E}
     *
     * @param fieldName
     * @param filterValue
     * @param converter
     * @param specifications
     * @return
     */
    protected <T extends Comparable<T>> Specification<E> getSpecification(String fieldName, String filterValue,
                                                                          Function<String, T> converter, FilterSpecifications<E, T> specifications) {

        if (StringUtils.isNotBlank(filterValue)) {

            // Form the filter Criteria
            FilterCriteria<T> criteria = new FilterCriteria<>(fieldName, filterValue, converter);
            return specifications.getSpecification(criteria.getOperation()).apply(criteria);
        }

        return null;

    }

}
