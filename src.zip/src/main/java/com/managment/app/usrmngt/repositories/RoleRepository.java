package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.Role;

public interface RoleRepository extends BaseRepository<Role, Long> {

    /**
     * Find {@link Role} instance by it's name
     * @param name
     * @return
     */
    Role findByName(String name);
}
