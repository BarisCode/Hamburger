package com.managment.app.usrmngt.security.utils;

import org.springframework.security.crypto.codec.Hex;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public abstract class TokenUtils {

    public static String createToken(String email, String password, Long sessionTimeOut) {
        long expires = System.currentTimeMillis() + sessionTimeOut *60*60;
        return email + ":" + expires + ":" + computeSignature(email, password, sessionTimeOut);
    }

    public static boolean validateToken(String token, String email, String password) {
        String[] parts = token.split(":");
        long expires = Long.parseLong(parts[1]);
        String signature = parts[2];
        String signatureToMatch = computeSignature(email, password, expires);
        return expires >= System.currentTimeMillis() && signature.equals(signatureToMatch);
    }

    public static String extractEmail(String token) {
        if (token == null) {
            return null;
        }
        String[] parts = token.split(":");
        return parts[0];
    }

    private static String computeSignature(String email, String password, Long sessionTimeOut) {
        StringBuilder builder = new StringBuilder();
        builder.append(email).append(":");
        builder.append(sessionTimeOut).append(":");
        builder.append(password).append(":");
        builder.append("boum");

        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            return new String(Hex.encode(digest.digest(builder.toString().getBytes())));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("No MD5 algorithm available");
        }
    }
}
