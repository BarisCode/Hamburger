package com.managment.app.usrmngt.entities.views;

import com.managment.app.usrmngt.entities.Product;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderItemViewModel {
    private Product product;
    private int count = 0;

    private double calculateTotal(){
        return product.getPrice() * count;
    }
}
