package com.managment.app.usrmngt.entities.views;

import lombok.Data;

import java.util.List;

@Data
public class RegisterViewModel {

    private Long id;

    private String firstName;

    private String lastName;

    private String password;

    private List<Long> courses;

    private RegistrationCourseViewModel course;
}
