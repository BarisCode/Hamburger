package com.managment.app.usrmngt.services;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.lang.Nullable;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface BaseService<E, K> {

    /**
     * Count all instance of E of the given {@link Example}
     * @param example
     * @return
     */
    long count(Example<E> example);

    /**
     * Count all instance of E of the given {@link Specification}
     * @param specification
     * @return
     */
    long count(Specification<E> specification);

    /**
     * Check if instance of E exists
     * @param example
     * @return
     */
    boolean exists(Example<E> example);

    /**
     * Check if instance of E exists by it's ID
     * @param id
     * @return
     */
    boolean existsById(K id);

    /**
     * Find instance of E by it's ID
     * @param id
     * @return
     */
    Optional<E> findById(K id);

    /**
     * Find instance of E by {@link Example}
     * @param example
     * @return
     */
    Optional<E> findOne(Example<E> example);

    /**
     * Find instance of E by {@link Specification}
     * @param specification
     * @return
     */
    Optional<E> findOne(Specification<E> specification);

    /**
     * Fetch all instances of E
     * @param input
     * @return
     */
    DataTablesOutput<E> findAll(DataTablesInput input);

    /**
     * Find all instances of E with the given {@link Example}
     * @param example
     * @param pageable
     * @return
     */
    Page<E> findAll(Example<E> example, Pageable pageable);

    /**
     * Find all instances of E with the given {@link Specification}
     * @param specification
     * @param pageable
     * @return
     */
    Page<E> findAll(@Nullable Specification<E> specification, Pageable pageable);

    /**
     * Fetch all instances created after a given date
     * @param date
     * @return
     */
    List<E> findByCreatedAtAfter(Date date);

    /**
     * Fetch all instances created between start date and end date
     * @param start
     * @param end
     * @return
     */
    List<E> findByCreatedAtBetween(Date start, Date end);

    /**
     * Fetch all instances with the given List id
     * @param ids
     * @return
     */
    List<E> findByIdIn(List<Long> ids);
}
