package com.managment.app.usrmngt.repositories;

import com.managment.app.usrmngt.entities.Product;

public interface ProductRepository extends BaseRepository<Product, Long>{

}
