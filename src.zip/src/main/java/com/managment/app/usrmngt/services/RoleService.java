package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Role;

public interface RoleService extends BaseService<Role, Long> {
}
