package com.managment.app.usrmngt.entities;

import lombok.NoArgsConstructor;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "users")
@NoArgsConstructor
@DiscriminatorValue("Cashier")
public class Cashier extends User {
}
