package com.managment.app.usrmngt.controllers.api.v1;

import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin/api/v1/users")
public class UsersRestController {

    @Autowired
    private UserService userService;

    @PostMapping("/all")
    public DataTablesOutput<User> list(@Valid @RequestBody DataTablesInput input) {
        DataTablesOutput<User> all = userService.findAll(input);
        return all;
    }

    @GetMapping("/find")
    public ResponseEntity<List<User>> fetchUserByType(@RequestParam Optional<List<String>> types) {
        List<String> filter = types.orElse(Arrays.asList("CASHIER"));
        return ResponseEntity.ok(userService.findByTypeIn(filter));
    }
}
