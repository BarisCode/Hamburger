package com.managment.app.usrmngt.controllers.web;

import com.managment.app.usrmngt.entities.Order;
import com.managment.app.usrmngt.entities.OrderItem;
import com.managment.app.usrmngt.entities.Product;
import com.managment.app.usrmngt.entities.views.OrderItemViewModel;
import com.managment.app.usrmngt.entities.views.OrdersViewModel;
import com.managment.app.usrmngt.services.OrderService;
import com.managment.app.usrmngt.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

@Controller
@RequestMapping("/order")
public class OrderController {
    private final static String VIEW_ORDER = "pages/auth/order";

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @GetMapping
    public String showOrder(Model model){
        Product filter = new Product();
        filter.setActive(true);
        final Page<Product> all = productService.findAll(Example.of(filter), Pageable.unpaged());
        final List<OrderItemViewModel> collect = all.getContent().stream().map(product ->
            OrderItemViewModel.builder().count(0).product(product).build()
        ).collect(toList());

        model.addAttribute("products", collect);
        model.addAttribute("orders", new OrdersViewModel());
        return VIEW_ORDER;
    }

    @PostMapping("/process")
    public String processOrder(@ModelAttribute("orders") OrdersViewModel orders){
        Order order = new Order();
        for (Map.Entry<Long, Integer> entry: orders.getOrderViewModel().entrySet()) {
            if(entry.getValue()!=null && entry.getValue()>0){
                final Optional<Product> byId = productService.findById(entry.getKey());
                byId.ifPresent(product -> {
                    OrderItem item =  OrderItem.builder().product(product).quantity(entry.getValue()).order(order).build();
                    order.getItems().add(item);
                });
            }
        }
        if(!order.getItems().isEmpty()){
            orderService.save(order);
        }
        return "redirect:/order";
    }
}
