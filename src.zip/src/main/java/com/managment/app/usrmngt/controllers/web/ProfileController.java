package com.managment.app.usrmngt.controllers.web;

import com.managment.app.usrmngt.entities.User;
import com.managment.app.usrmngt.entities.views.UserProfileViewModel;
import com.managment.app.usrmngt.services.UserService;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Map;

@Controller
@RequestMapping("/profile")
public class ProfileController {
    static final String VIEW_PROFILE = "pages/admin/profile";

    @Autowired
    private UserService userService;

    /**
     * {@link MapperFacade} instance for converting {@link User}
     * instance to {@link UserProfileViewModel}.
     */
    @Autowired
    @Qualifier(value = "mapperUserToUserProfileViewModel")
    private MapperFacade mapperUserToUserProfileViewModel;

    @GetMapping
    public String showUserProfile(HttpServletRequest servletRequest,
                                  Model model) {
        Map<String, String[]> paramMap = servletRequest.getParameterMap();
        if (!paramMap.isEmpty()) {
            model.addAttribute("message_type", paramMap.containsKey("success") ? "success" : "danger");
            model.addAttribute("message", paramMap.containsKey("success") ? "Your profile have been updated" :
                    "Error happens while updating your profile! Please, retry!");
        }
        Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByEmail(loggedInUser.getName()).orElse(null);

        UserProfileViewModel viewModel = mapperUserToUserProfileViewModel.map(user, UserProfileViewModel.class);
        model.addAttribute("user_profile", viewModel);
        return VIEW_PROFILE;
    }

    @PostMapping("/{id}")
    public String processUserProfile(@PathVariable("id") Long id,
                                     @Valid UserProfileViewModel model,
                                     RedirectAttributes redirectAttributes) {
        if (!userService.existsById(id)) {
            redirectAttributes.addFlashAttribute("user", "User not found!!!");
            return "redirect:/profile?error";
        }

        userService.update(model);
        return "redirect:/profile?success";
    }
}
