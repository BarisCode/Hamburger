package com.managment.app.usrmngt.misc;

import lombok.extern.slf4j.Slf4j;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.time.Duration;

@Slf4j
@Converter(autoApply = true)
public class DurationConverter implements AttributeConverter<Duration, Long> {

    @Override
    public Long convertToDatabaseColumn(Duration attribute) {
        log.info("Convert to Long");
        return attribute.toMillis();
    }

    @Override
    public Duration convertToEntityAttribute(Long duration) {
        log.info("Convert to Duration: " + duration);
        return Duration.ofMillis(duration);
    }
}

