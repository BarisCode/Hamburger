package com.managment.app.usrmngt.entities.views;

import lombok.Data;

@Data
public class AddressViewModel {

    private Long id;

    private String street;

    private String city;

    private String country;

    private String postCode;
}
