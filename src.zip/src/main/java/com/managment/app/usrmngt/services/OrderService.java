package com.managment.app.usrmngt.services;

import com.managment.app.usrmngt.entities.Order;

public interface OrderService extends BaseService<Order, Long> {

    Order save(Order order);
}