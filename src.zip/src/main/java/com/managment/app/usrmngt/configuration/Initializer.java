package com.managment.app.usrmngt.configuration;

import com.managment.app.usrmngt.entities.*;
import com.managment.app.usrmngt.entities.views.UserType;
import com.managment.app.usrmngt.repositories.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.data.domain.Example;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Component
public class Initializer implements ApplicationListener<ContextRefreshedEvent> {

    @Value("${application.initialize.persistence}")
    private boolean initializeDefaultUser;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private PrivilegeRepository privilegeRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        if (initializeDefaultUser) {
            //  log.info("Initializing default user");
            setupStartupSecurityContext();
            // == create initial privileges
            final Privilege readPrivilege
                    = createPrivilegeIfNotFound("READ_PRIVILEGE");
            final Privilege writePrivilege
                    = createPrivilegeIfNotFound("WRITE_PRIVILEGE");
            final Privilege passwordPrivilege = createPrivilegeIfNotFound("CHANGE_PASSWORD_PRIVILEGE");
            final Privilege adminPrivilege
                    = createPrivilegeIfNotFound("ADMIN_PRIVILEGE");
            final Privilege cashierPrivilege
                    = createPrivilegeIfNotFound("CASHIER_PRIVILEGE");

            // == create initial roles
            final List<Privilege> adminPrivileges = new ArrayList<Privilege>(Arrays.asList(readPrivilege, writePrivilege, passwordPrivilege, adminPrivilege));
            final List<Privilege> userPrivileges = new ArrayList<Privilege>(Arrays.asList(readPrivilege, passwordPrivilege));
            final List<Privilege> cashierPrivileges = new ArrayList<Privilege>(Arrays.asList(readPrivilege, passwordPrivilege,cashierPrivilege));
            final Role adminRole = createRoleIfNotFound("ADMIN", adminPrivileges.stream().collect(Collectors.toSet()));
            final Role cashierRole = createRoleIfNotFound("CASHIER", cashierPrivileges.stream().collect(Collectors.toSet()));
            createRoleIfNotFound("USER", userPrivileges.stream().collect(Collectors.toSet()));

            // == create initial users
            createUserIfNotFound("admin@yopmail.com", "Super", "Admin", "password",
                    UserType.ADMIN, Arrays.asList(adminRole).stream().collect(Collectors.toSet()));
            createUserIfNotFound("cashier@yopmail.com","cashier", "one","baris123",
                  UserType.CASHIER, Arrays.asList(cashierRole).stream().collect(Collectors.toSet()));


            // == create initial products
            createProductIfNotFound("Hamburger with Cheese",10);
            createProductIfNotFound("Hamburger without Cheese",9);
            createProductIfNotFound("Chips",4);
            createProductIfNotFound("Coke",2);

            unloadStartupSecurityContext();
        }
    }


    @Transactional
    private Privilege createPrivilegeIfNotFound(String name) {

        Privilege privilege = privilegeRepository.findByName(name);
        if (privilege == null) {
            privilege = new Privilege(name);
            privilege = privilegeRepository.save(privilege);
        }
        return privilege;
    }

    @Transactional
    private Role createRoleIfNotFound(
            String name, Set<Privilege> privileges) {

        Role role = roleRepository.findByName(name);
        if (role == null) {
            role = new Role(name);
            role.setPrivileges(privileges);
            role = roleRepository.save(role);
        }
        return role;
    }

    @Transactional
    private final User createUserIfNotFound(final String email,
                                            final String firstName,
                                            final String lastName,
                                            final String password,
                                            final UserType type,
                                            final Set<Role> roles) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            user = new User();
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setPassword(passwordEncoder.encode(password));
            user.setEmail(email);
        }

        Address address = Address.builder().city("Melbourne")
                .country("Australia")
                .postCode("3000")
                .street("268 Flinders Street")
                .build();
        user.setAddress(address);

        user.setRoles(roles);
        user = userRepository.save(user);
        return user;
    }

    private void setupStartupSecurityContext() {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority("ADMIN"));

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("admin@app.com", "password", grantedAuthorities);
        SecurityContextHolder.getContext().setAuthentication(token);

    }

    private void unloadStartupSecurityContext() {
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Transactional
    private void createProductIfNotFound(String name,double price){
        Product product = Product.builder().name(name).price(price).build();
        if (!productRepository.exists(Example.of(Product.builder().name(name).build()))){
            productRepository.save(product); // save product if not already exist
        }
    }

}
