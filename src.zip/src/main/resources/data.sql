-- Used by Spring Remember Me API.
CREATE TABLE IF NOT EXISTS Persistent_Logins
(
    username varchar(64) not null,
    series varchar(64) not null,
    token varchar(64) not null,
    last_used timestamp not null,
    PRIMARY KEY (series)
);