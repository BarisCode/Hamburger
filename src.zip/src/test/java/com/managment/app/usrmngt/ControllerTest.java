package com.managment.app.usrmngt;
import static org.assertj.core.api.Assertions.assertThat;

import com.managment.app.usrmngt.controllers.web.OrderController;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ControllerTest {

    @Autowired
    private OrderController controller;

    @Test
    public void contextLoads() throws Exception {
        assertThat(controller).isNotNull();
    }
}