package com.managment.app.usrmngt;

import static org.assertj.core.api.Assertions.assertThat;

import com.managment.app.usrmngt.entities.Order;
import com.managment.app.usrmngt.entities.OrderItem;
import com.managment.app.usrmngt.entities.Product;
import com.managment.app.usrmngt.repositories.OrderRepository;
import com.managment.app.usrmngt.repositories.ProductRepository;
import com.managment.app.usrmngt.services.OrderService;
import com.managment.app.usrmngt.services.OrderServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@DataJpaTest
public class OrderRepositoryIntegrationTest {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Test
    public void should_save_order() {
        Product product = Product.builder().name("coke").price(2.0).build();
        final Product productSaved = productRepository.save(product);
        List<OrderItem> items = new ArrayList<>();
        items.add(OrderItem.builder().product(productSaved).quantity(5).build());
        Order order = Order.builder().items(items).build();
        assertThat(orderRepository.save(order)).isNotNull();
    }

    @TestConfiguration
    static class EmployeeServiceImplTestContextConfiguration {

        @Bean
        public OrderService OrderService() {
            return new OrderServiceImpl();
        }
    }

}

